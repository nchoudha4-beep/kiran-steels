import React from 'react';
import { CheckCircle } from 'lucide-react';

const Products: React.FC = () => {
  const products = [
    {
      title: "Steel Pipes",
      description: "High-quality steel pipes for construction and industrial applications",
      features: ["MS Pipes", "GI Pipes", "Seamless Pipes", "Welded Pipes"],
      image: "https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    },
    {
      title: "Steel Rods & Bars",
      description: "Premium quality steel rods and bars for construction projects",
      features: ["TMT Bars", "MS Rounds", "Square Bars", "Flat Bars"],
      image: "https://images.pexels.com/photos/1598300/pexels-photo-1598300.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    },
    {
      title: "Steel Sheets",
      description: "Various types of steel sheets for diverse industrial needs",
      features: ["MS Sheets", "Chequered Plates", "Hot Rolled Sheets", "Cold Rolled Sheets"],
      image: "https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    },
    {
      title: "Structural Steel",
      description: "Heavy-duty structural steel for construction and engineering",
      features: ["I-Beams", "H-Beams", "Angles", "Channels"],
      image: "https://images.pexels.com/photos/162557/architecture-building-construction-work-162557.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    },
    {
      title: "Stainless Steel",
      description: "Corrosion-resistant stainless steel products",
      features: ["SS Pipes", "SS Sheets", "SS Fittings", "SS Fasteners"],
      image: "https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    },
    {
      title: "Jindal Products",
      description: "Authorized dealer for Jindal Steel products",
      features: ["Jindal Pipes", "Jindal TMT", "Jindal Sheets", "Premium Quality"],
      image: "https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
    }
  ];

  return (
    <section id="products" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Our Products</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Comprehensive range of steel products to meet all your construction and industrial requirements
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {products.map((product, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src={product.image} 
                alt={product.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800 mb-3">{product.title}</h3>
                <p className="text-slate-600 mb-4">{product.description}</p>
                <ul className="space-y-2">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center space-x-2">
                      <CheckCircle className="text-green-500" size={16} />
                      <span className="text-slate-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="mt-4 w-full bg-blue-800 text-white py-2 rounded-lg hover:bg-blue-900 transition-colors">
                  Get Quote
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-slate-800 rounded-xl p-8 text-center">
          <h3 className="text-3xl font-bold text-white mb-4">Need Custom Steel Solutions?</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            We provide customized steel products according to your specifications. 
            Contact us for bulk orders and special requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+919876543210" 
              className="bg-orange-500 text-white px-8 py-3 rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              Call for Custom Quote
            </a>
            <a 
              href="https://wa.me/919876543210" 
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-slate-800 transition-colors"
            >
              WhatsApp Inquiry
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Products;