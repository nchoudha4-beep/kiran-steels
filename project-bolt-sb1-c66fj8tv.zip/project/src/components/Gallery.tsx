import React from 'react';

const Gallery: React.FC = () => {
  const galleryImages = [
    {
      src: "https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Steel pipes inventory",
      title: "Steel Pipes"
    },
    {
      src: "https://images.pexels.com/photos/1598300/pexels-photo-1598300.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Steel rods and bars",
      title: "Steel Rods & Bars"
    },
    {
      src: "https://images.pexels.com/photos/1267338/pexels-photo-1267338.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Steel sheets",
      title: "Steel Sheets"
    },
    {
      src: "https://images.pexels.com/photos/162557/architecture-building-construction-work-162557.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Structural steel",
      title: "Structural Steel"
    },
    {
      src: "https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Warehouse facility",
      title: "Our Warehouse"
    },
    {
      src: "https://images.pexels.com/photos/1598300/pexels-photo-1598300.jpeg?auto=compress&cs=tinysrgb&w=500&h=400&fit=crop",
      alt: "Quality control",
      title: "Quality Control"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">Gallery</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Take a look at our extensive inventory, modern facilities, and quality steel products
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <img 
                src={image.src} 
                alt={image.alt}
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4">
                  <h3 className="text-white font-semibold text-lg">{image.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-slate-600 mb-6">
            Want to see our full inventory? Visit our store or schedule a facility tour.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+919876543210" 
              className="bg-blue-800 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-900 transition-colors"
            >
              Schedule Visit
            </a>
            <a 
              href="#contact" 
              className="border-2 border-blue-800 text-blue-800 px-8 py-3 rounded-lg font-semibold hover:bg-blue-800 hover:text-white transition-colors"
            >
              Get Directions
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;