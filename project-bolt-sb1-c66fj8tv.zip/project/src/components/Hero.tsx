import React from 'react';
import { Phone, MapPin, Award } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center">
      {/* Background with overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url("https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop")'
        }}
      >
        <div className="absolute inset-0 bg-slate-900 bg-opacity-70"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
            Kiran <span className="text-orange-400">Steels</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed">
            Your trusted partner for premium steel products in Gopalpatnam. 
            Quality materials, competitive prices, and exceptional service since our establishment.
          </p>
          
          {/* Key Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
            <div className="flex items-center space-x-3 bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
              <Award className="text-orange-400" size={24} />
              <div>
                <h3 className="font-semibold text-white">Premium Quality</h3>
                <p className="text-gray-300 text-sm">Certified steel products</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
              <MapPin className="text-orange-400" size={24} />
              <div>
                <h3 className="font-semibold text-white">Prime Location</h3>
                <p className="text-gray-300 text-sm">Gopalpatnam, Visakhapatnam</p>
              </div>
            </div>
            <div className="flex items-center space-x-3 bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-4">
              <Phone className="text-orange-400" size={24} />
              <div>
                <h3 className="font-semibold text-white">24/7 Support</h3>
                <p className="text-gray-300 text-sm">Always available</p>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="flex flex-col sm:flex-row gap-4">
            <a 
              href="tel:+919876543210" 
              className="bg-blue-800 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-900 transition-colors text-center flex items-center justify-center space-x-2"
            >
              <Phone size={20} />
              <span>Call Now</span>
            </a>
            <a 
              href="#products" 
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-slate-900 transition-colors text-center"
            >
              View Products
            </a>
            <a 
              href="https://wa.me/919876543210" 
              className="bg-orange-500 text-white px-8 py-4 rounded-lg font-semibold hover:bg-orange-600 transition-colors text-center"
            >
              WhatsApp Inquiry
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;