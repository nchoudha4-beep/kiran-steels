import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: "Rajesh Kumar",
      business: "Kumar Construction",
      rating: 5,
      text: "Kiran Steels has been our go-to supplier for all steel requirements. Excellent quality products and timely delivery every time.",
      image: "https://images.pexels.com/photos/1391498/pexels-photo-1391498.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    {
      name: "Priya Sharma",
      business: "Sharma Industries",
      rating: 5,
      text: "Outstanding service and competitive prices. The team at Kiran Steels is professional and always ready to help with our bulk orders.",
      image: "https://images.pexels.com/photos/1587009/pexels-photo-1587009.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    {
      name: "Anil Reddy",
      business: "Reddy Builders",
      rating: 5,
      text: "Top-notch quality steel products. Kiran Steels has never disappointed us. Highly recommended for all construction needs.",
      image: "https://images.pexels.com/photos/1391499/pexels-photo-1391499.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    },
    {
      name: "Lakshmi Devi",
      business: "Devi Engineering Works",
      rating: 5,
      text: "Reliable supplier with excellent customer service. The steel quality is consistently good and delivery is always on time.",
      image: "https://images.pexels.com/photos/1587010/pexels-photo-1587010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop"
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        size={16} 
        className={i < rating ? "text-yellow-400 fill-current" : "text-gray-300"} 
      />
    ));
  };

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">What Our Customers Say</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Trusted by construction companies and industries across Visakhapatnam
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 rounded-lg p-6 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-start space-x-1 mb-4">
                {renderStars(testimonial.rating)}
              </div>
              
              <div className="relative mb-6">
                <Quote className="absolute -top-2 -left-2 text-blue-800 opacity-20" size={32} />
                <p className="text-slate-700 leading-relaxed pl-6">
                  "{testimonial.text}"
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-semibold text-slate-800">{testimonial.name}</h4>
                  <p className="text-slate-600 text-sm">{testimonial.business}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Google Reviews CTA */}
        <div className="text-center mt-12 bg-slate-800 rounded-xl p-8">
          <h3 className="text-2xl font-bold text-white mb-4">See More Reviews</h3>
          <p className="text-gray-300 mb-6">
            Check out our Google Business Profile and JustDial reviews to see what more customers are saying
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="#" 
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Google Reviews
            </a>
            <a 
              href="#" 
              className="bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition-colors"
            >
              JustDial Reviews
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;