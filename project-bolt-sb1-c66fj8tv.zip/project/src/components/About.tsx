import React from 'react';
import { Shield, Users, Truck, Award } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-800 mb-4">About Kiran Steels</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            A trusted name in the steel industry, serving Gopalpatnam and surrounding areas 
            with premium quality steel products and exceptional customer service.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-bold text-slate-800 mb-6">Our Story</h3>
            <p className="text-slate-600 mb-6 leading-relaxed">
              Established with a vision to provide high-quality steel products to the construction 
              and manufacturing industries, Kiran Steels has become a cornerstone of reliability 
              in Gopalpatnam, Visakhapatnam.
            </p>
            <p className="text-slate-600 mb-6 leading-relaxed">
              We specialize in a comprehensive range of steel products including pipes, rods, 
              sheets, and structural steel. Our commitment to quality and customer satisfaction 
              has earned us recognition on platforms like Google Business and JustDial.
            </p>
            <p className="text-slate-600 leading-relaxed">
              With strong partnerships with leading brands like Jindal Steel and a focus on 
              wholesale distribution, we ensure competitive pricing without compromising on quality.
            </p>
          </div>
          <div className="relative">
            <img 
              src="https://images.pexels.com/photos/1105766/pexels-photo-1105766.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
              alt="Steel manufacturing facility"
              className="rounded-lg shadow-xl"
            />
            <div className="absolute -bottom-6 -right-6 bg-blue-800 text-white p-6 rounded-lg">
              <p className="text-2xl font-bold">15+</p>
              <p className="text-sm">Years Experience</p>
            </div>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="text-blue-800" size={32} />
            </div>
            <h4 className="text-xl font-bold text-slate-800 mb-2">Quality Assured</h4>
            <p className="text-slate-600">All products undergo strict quality checks and meet industry standards.</p>
          </div>

          <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="text-orange-500" size={32} />
            </div>
            <h4 className="text-xl font-bold text-slate-800 mb-2">Expert Team</h4>
            <p className="text-slate-600">Experienced professionals committed to serving your steel needs.</p>
          </div>

          <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Truck className="text-green-600" size={32} />
            </div>
            <h4 className="text-xl font-bold text-slate-800 mb-2">Fast Delivery</h4>
            <p className="text-slate-600">Timely delivery to your location across Visakhapatnam and nearby areas.</p>
          </div>

          <div className="text-center p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="text-purple-600" size={32} />
            </div>
            <h4 className="text-xl font-bold text-slate-800 mb-2">Trusted Brand</h4>
            <p className="text-slate-600">Recognized on Google Business and JustDial for excellence.</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;