import React from 'react';
import { Phone, Mail, MapPin, MessageCircle, Star } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-blue-800 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">KS</span>
              </div>
              <div>
                <h3 className="text-xl font-bold">Kiran Steels</h3>
                <p className="text-sm text-gray-400">Quality Steel Products</p>
              </div>
            </div>
            <p className="text-gray-300 mb-4">
              Your trusted partner for premium steel products in Gopalpatnam, Visakhapatnam. 
              Quality materials, competitive prices, and exceptional service.
            </p>
            <div className="flex items-center space-x-1">
              {Array.from({ length: 5 }, (_, i) => (
                <Star key={i} size={16} className="text-yellow-400 fill-current" />
              ))}
              <span className="ml-2 text-sm text-gray-300">4.9/5 Rating</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">About Us</a></li>
              <li><a href="#products" className="text-gray-300 hover:text-white transition-colors">Products</a></li>
              <li><a href="#gallery" className="text-gray-300 hover:text-white transition-colors">Gallery</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Products */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Our Products</h4>
            <ul className="space-y-2">
              <li><span className="text-gray-300">Steel Pipes</span></li>
              <li><span className="text-gray-300">Steel Rods & Bars</span></li>
              <li><span className="text-gray-300">Steel Sheets</span></li>
              <li><span className="text-gray-300">Structural Steel</span></li>
              <li><span className="text-gray-300">Stainless Steel</span></li>
              <li><span className="text-gray-300">Jindal Products</span></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <MapPin className="text-orange-400 mt-1" size={16} />
                <div>
                  <p className="text-gray-300 text-sm">
                    Kiran Steels, Gopalpatnam<br />
                    Visakhapatnam, Andhra Pradesh
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="text-orange-400" size={16} />
                <a href="tel:+919876543210" className="text-gray-300 hover:text-white text-sm">
                  +91 98765 43210
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="text-orange-400" size={16} />
                <a href="mailto:info@kiransteels.com" className="text-gray-300 hover:text-white text-sm">
                  info@kiransteels.com
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <MessageCircle className="text-orange-400" size={16} />
                <a href="https://wa.me/919876543210" className="text-gray-300 hover:text-white text-sm">
                  WhatsApp Us
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 Kiran Steels. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm">Privacy Policy</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Terms of Service</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Google Business</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">JustDial</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;